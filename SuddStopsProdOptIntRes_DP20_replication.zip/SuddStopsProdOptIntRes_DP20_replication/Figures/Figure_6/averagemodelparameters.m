% MATLAB program averagemodelparameters.m
% First created: 26 April 2016 by Harun Nasir
% Last modified: 1 January 2021 by Alexander Mihailov

% Average dynamics of key variables in sudden stops between 1980 and 2014. 
% The sudden stops inside the five year event period of the previous sudden 
% stops were eliminated.

% The data vectors (below) use as input data in ModParam.xlsx.

%% Housekeeping

close all

global Yt It FA Rt At t 

%% Variables and their standard deviation bands

Yt=[102.21	111.92	100	98.18	113.56];
It=[25.8	25.6	23.1	21.4 22.5];
FA=[5.54	8.1 -2.3 -0.4	2.3];
Rt=[-1.8	-2.94	3.99  0.89 -1.17];

At=Yt-It+FA-Rt; 
StdA=std(At);
stdA1=At+StdA;
stdA2=At-StdA;

stdFA=std(FA);
stdFA1=FA+stdFA;
stdFA2=FA-stdFA;

stdI=std(It);
stdI1=It+stdI;
stdI2=It-stdI;

stdR=std(Rt);
stdR1=Rt+stdR;
stdR2=Rt-stdR;

%% Multiple plotting of all time series

At=Yt-It+FA-Rt;
t=(-2:2);
figure
print -deps figure6.eps
h1=subplot(2,3,1);
plot(t,At,'b','Linewidth',2),hold on, plot(t,stdA1,'r--','Linewidth',2), hold on, plot(t,stdA2,'r--','Linewidth',2)
xlabel('Time','Fontsize',14)
title('Consumption','Fontsize',14)
set(gca,'fontsize',12)

hL=legend('Mean','One Standard Error Band','Location','south','Orientation','horizontal');

Yt=[102.21	111.92	100	98.18	113.56];
stdY=std(Yt);
stdY1=Yt+stdY;
stdY2=Yt-stdY;
t=(-2:2);
h2=subplot(2,3,2);
plot(t,Yt,'b','Linewidth',2), hold on, plot(t,stdY1,'r--','Linewidth',2), hold on, plot(t,stdY2,'r--','Linewidth',2)
xlabel('Time','Fontsize',14)
title('Domestic Output','Fontsize',14)
set(gca,'fontsize',12)

FA=[5.54	8.1 -2.3 -0.4	2.3];
t=(-2:2);
h3=subplot(2,3,3);
plot(t,FA,'b','Linewidth',2), hold on, plot(t,stdFA1,'r--','Linewidth',2), hold on, plot(t,stdFA2,'r--','Linewidth',2)
xlabel('Time','Fontsize',14)
title('Financial Account','Fontsize',14)
set(gca,'fontsize',12)

It=[25.8	25.6	23.1	21.4 22.5];
t=(-2:2);
h4=subplot(2,3,4);
plot(t,It,'b','Linewidth',2), hold on, plot(t,stdI1,'r--','Linewidth',2), hold on, plot(t,stdI2,'r--','Linewidth',2)
xlabel('Time','Fontsize',14)
title('Investment','Fontsize',14)
set(gca,'fontsize',12)

Rt=[-1.8	-2.94	3.99  0.89 -1.17];
t=(-2:2);
h5=subplot(2,3,5);
plot(t,Rt,'b','Linewidth',2),  hold on, plot(t,stdR1,'r--','Linewidth',2), hold on, plot(t,stdR2,'r--','Linewidth',2)
xlabel('Time','Fontsize',14)
title('Change in Reserves','Fontsize',14)
set(gca,'fontsize',12)
