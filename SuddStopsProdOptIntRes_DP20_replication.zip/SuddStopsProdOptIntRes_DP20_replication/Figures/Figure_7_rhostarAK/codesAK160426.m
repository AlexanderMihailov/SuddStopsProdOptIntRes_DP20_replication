% MATLAB program codesAK160426.m
% First created: 26 April 2016 by Harun Nasir
% Last modified: 31 December 2020 by Alexander Mihailov

% Computation of the optimal reserves to output ratio for the AK production
% model version

clc 
clear all 
close all 
global r p A gamma sigma lambda delta pi s k pery

% Parameter calibration

lambda=0.10; %J&R 2011 
pi=0.10;     %J&R 2011
gamma=0.065; %J&R 2011
p=0.855;     %J&R 2011
r=0.05;      %J&R 2011
sigma=2;     %J&R 2011
delta=0.06;  %Gourinchas&Jeanne 2007 & Caselli 2005
s=0.24;      %from sample (PWT(7.0) 
pery=15141;  %from sample (PWT 7.0)
k=2.49*pery; % (PWT 7.0 from 1975 to 2009)
A=(pery/(k)); 

% Optimal reserves formula

rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));

% Multiple plotting

A=0.10:0.01:0.70;
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
figure %create new figure
subplot(3,3,1)%first subplot
plot(A,rhostar, 'Linewidth',2)
xlabel('Productivity Constant','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
ylim([0 0.50])
set(gca,'fontsize',12)

A=(pery/(k));
lambda=0:0.01:0.25; %definex2
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
subplot(3,3,2) %second subplot
plot(lambda,rhostar,'Linewidth',2)
xlabel('Size of Sudden Stop','Fontsize',14)
ylabel ('Reserves/GDP','Fontsize',14)
ylim([0 0.3])
set(gca,'fontsize',12)

lambda=0.10;
gamma=0:0.01:0.25; %define x3
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
subplot(3,3,3) %third suplot
plot(gamma,rhostar,'Linewidth',2)
xlabel('Output Cost','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
ylim([0 0.3])
set(gca,'fontsize',12)

gamma=0.065;
pi=0:0.01:0.20; %define x4
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
subplot(3,3,4) %fourth subplot
plot(pi,rhostar,'Linewidth',2)
xlabel('Probability of Sudden Stop','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
%ylim([0.06 0.062])
set(gca,'fontsize',12)

pi=0.10;
s=0:0.01:0.30; %define x5
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
subplot(3,3,5) %fifth subplot
plot(s,rhostar,'Linewidth',2)
xlabel('Investment Rate','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
ylim([0 0.25])
set(gca,'fontsize',12)

s=0.24;
delta=0.01:0.01:0.2; %define x6
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
subplot(3,3,6) %sixth subplot
plot(delta,rhostar,'Linewidth',2)
xlabel('Depreciation Rate of Capital','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
ylim([0 0.25])
set(gca,'fontsize',12)

delta=0.06;
r=0:0.01:0.2; %define x7
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
subplot (3,3,7) %seventh subplot
plot(r,rhostar,'Linewidth',2)
xlabel('Interest Rate','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
%ylim([0.06 0.062])
set(gca,'fontsize',12)

r=0.05;
sigma=1:0.01:10; %define x8
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
%rhostar=(gamma+lambda+(delta.*(A.^-1))-((p.^(1./sigma)).*s)+(1-p.^(1./sigma))-(((1-p.^(1./sigma)).*(lambda)).*((r-(s.*A-delta))./(1+(s.*A-delta)))))./((1-(pi.*((pi+p.*(1-pi)).^-1)).*(1-p.^(sigma.^-1))));
subplot(3,3,8) %eighth subplot
plot(sigma,rhostar,'Linewidth',2)
xlabel('Risk Aversion','Fontsize',14)
ylabel('Reserves/GDP','Fontsize',14)
ylim([0 0.125])
set(gca,'fontsize',12)

sigma=2;
rhostar=(gamma+lambda+(delta./A)-((p.^(1./sigma)).*s)-(1-p.^(1./sigma))+(((1-p.^(1./sigma)).*lambda).*((r-(s.*A-delta)))./(1+(s.*A-delta))))./(1-(pi.*(1-p.^(1./sigma)))./(pi+p.*(1-pi)));
